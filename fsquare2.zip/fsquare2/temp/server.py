--- /home/uyar/Projects/flask-tutorial/app/v0302b/server.py
+++ /home/uyar/Projects/flask-tutorial/app/v0401/server.py
@@ -12,10 +12,11 @@
     app.add_url_rule("/", view_func=views.home_page)
     app.add_url_rule("/movies", view_func=views.movies_page)
     app.add_url_rule("/movies/<int:movie_key>", view_func=views.movie_page)
+    app.add_url_rule(
+        "/new-movie", view_func=views.movie_add_page, methods=["GET", "POST"]
+    )
 
     db = Database()
-    db.add_movie(Movie("Slaughterhouse-Five", year=1972))
-    db.add_movie(Movie("The Shining"))
     app.config["db"] = db
 
     return app
