# forms.py

from wtforms import Form, StringField, SelectField, validators

class MusicSearchForm(Form):
   choices = [('Colleges & Universities', 'Colleges & Universities'),
              ('Food', 'Food'),
              ('Publisher!', 'Publisher!')]
   select = SelectField('Search:', choices=choices)
   search = StringField('')
